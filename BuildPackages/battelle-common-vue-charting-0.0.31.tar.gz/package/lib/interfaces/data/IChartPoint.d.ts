export interface IChartPoint {
    x: number | string | Date;
    y: number | string | Date;
}
