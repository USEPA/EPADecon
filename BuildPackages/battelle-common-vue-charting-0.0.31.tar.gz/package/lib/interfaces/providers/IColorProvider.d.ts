export interface IColorProvider {
    getNextColor(): string;
}
