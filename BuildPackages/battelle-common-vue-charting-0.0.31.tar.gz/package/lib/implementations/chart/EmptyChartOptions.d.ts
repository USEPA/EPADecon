import { ChartOptions } from 'chart.js';
export declare const EmptyChartOptions: ChartOptions;
