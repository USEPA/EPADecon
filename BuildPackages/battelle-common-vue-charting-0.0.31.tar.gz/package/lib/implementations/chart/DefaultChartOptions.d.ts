import { ChartOptions } from 'chart.js';
export declare function CreateDefaultChartOptions(): ChartOptions;
