import { PointOptions } from 'chart.js';
export declare function CreateDefaultChartPointOptions(): Partial<PointOptions>;
