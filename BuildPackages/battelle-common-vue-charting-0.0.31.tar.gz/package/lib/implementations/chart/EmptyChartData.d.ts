import { ChartData } from 'chart.js';
export declare const EmptyChartData: ChartData;
