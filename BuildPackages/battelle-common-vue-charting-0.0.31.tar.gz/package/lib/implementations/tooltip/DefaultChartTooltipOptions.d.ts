import { ChartType, TooltipOptions } from 'chart.js';
export declare const ChartTooltipOptionsDefaultSettings: Partial<TooltipOptions<ChartType>>;
export declare function CreateDefaultTooltipOptions(): typeof ChartTooltipOptionsDefaultSettings;
