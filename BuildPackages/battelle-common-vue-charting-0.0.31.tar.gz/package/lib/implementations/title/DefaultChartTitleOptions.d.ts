import { TitleOptions } from 'chart.js';
export declare const ChartTitleDefaultSettings: TitleOptions;
export declare function CreateDefaultTitleOptions(): typeof ChartTitleDefaultSettings;
